class User {
  String email;
  String password;
  User(this.email, this.password);
}
