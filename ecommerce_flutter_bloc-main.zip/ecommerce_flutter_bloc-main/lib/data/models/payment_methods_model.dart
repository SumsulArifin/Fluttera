enum PaymentMethods {
  cod,
  razorpay,
}
