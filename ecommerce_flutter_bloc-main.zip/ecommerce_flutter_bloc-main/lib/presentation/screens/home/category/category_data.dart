part of 'category_imports.dart';

class CategoryData {}
