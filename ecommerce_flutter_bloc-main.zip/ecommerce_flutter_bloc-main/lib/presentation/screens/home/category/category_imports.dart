import 'package:ecommerce_flutter_bloc/data/models/models.dart';
import 'package:ecommerce_flutter_bloc/presentation/screens/home/widgets/widgets_imports.dart';
import 'package:flutter/material.dart';
import 'package:velocity_x/velocity_x.dart';

part 'category.dart';
part 'category_data.dart';
