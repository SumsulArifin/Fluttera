part of 'home_imports.dart';

class HomeData {}
