import 'package:auto_route/auto_route.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:ecommerce_flutter_bloc/data/models/models.dart';
import 'package:flutter/material.dart';
import 'package:line_icons/line_icon.dart';
import 'package:velocity_x/velocity_x.dart';

part 'product.dart';
part 'product_data.dart';
