part of 'product_imports.dart';

class ProductData {}
