import 'dart:async';
import 'package:auto_route/auto_route.dart';
import 'package:ecommerce_flutter_bloc/presentation/router/router_imports.gr.dart';
import 'package:flutter/material.dart';
import 'package:velocity_x/velocity_x.dart';

part 'splash.dart';
