package com.example.ecommerce_flutter_bloc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
